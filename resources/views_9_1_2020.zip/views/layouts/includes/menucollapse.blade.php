<div class="well well-sm visible-sm visible-xs">
    Top menu can become any of the 3 mobile view menu styles:
    <em>default</em>
    ,
    <em>collapsible</em>
    or
    <em>minimized</em>.
</div>

<div class="hidden-sm hidden-xs">
    <button type="button" class="sidebar-collapse btn btn-white btn-primary" data-target="#sidebar">
        <i class="ace-icon fa fa-angle-double-up" data-icon1="ace-icon fa fa-angle-double-up" data-icon2="ace-icon fa fa-angle-double-down"></i>
        Collapse/Expand Menu
    </button>
</div>