<script>
    $(document).ready(function () {

        $('#filter-btn').click(function () {

            @include('student.includes.common-script.student_filter_common_script')

                location.href = url;

        });

    });
</script>

